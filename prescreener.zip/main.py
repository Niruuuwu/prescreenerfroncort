"""
main.py — CLI Entry Point for Type 2 Diabetes Trial Pre-Screening Agent.

Provides a clean, inspectable CLI for reviewers with the following flags:
  --patient <id>     Run full pipeline for one patient and print readable report.
  --list-patients    Print dataset patient IDs, age, active med count, & missing domains.
  --all              Run all 15 patients in sequence and print a 1-line summary per patient.
  --out <path>.json  Save full JSON report to specified file (used with --patient).
  --verbose          Enable per-stage LangGraph state logging.
  --no-cache         Bypass extraction cache to force fresh LLM calls without overwriting cache.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from typing import Any

from prescreener.runner import prescreen_patient


DATASET_PATH = "data/Type2-Diabetes-Trial-Agent-Dataset.json"


def load_dataset(dataset_path: str = DATASET_PATH) -> dict[str, Any]:
    if not os.path.exists(dataset_path):
        print(f"Error: Dataset file not found at '{dataset_path}'", file=sys.stderr)
        sys.exit(1)
    with open(dataset_path, encoding="utf-8") as f:
        return json.load(f)


def get_patient_summary_info(patient: dict) -> tuple[str, Any, int, list[str]]:
    pid = patient["patient_id"]
    demographics = patient.get("demographics", {})
    age = demographics.get("age_at_reference_date", "N/A")
    
    medications = patient.get("medications", [])
    active_meds_count = sum(1 for m in medications if m.get("status") == "active")
    
    missing_domains = patient.get("record_quality", {}).get("missing_expected_domains", [])
    return pid, age, active_meds_count, missing_domains


def list_patients(dataset: dict[str, Any]) -> None:
    print("================================================================================")
    print("PATIENTS IN DATASET")
    print("================================================================================")
    for p in dataset.get("patients", []):
        pid, age, active_meds_count, missing_domains = get_patient_summary_info(p)
        missing_str = ", ".join(missing_domains) if missing_domains else "None"
        print(f"Patient {pid:7s} | Age: {str(age):>2s} | Active Meds: {active_meds_count} | Missing Domains: {missing_str}")
    print("================================================================================")


def print_patient_report(res: dict[str, Any]) -> None:
    pid = res.get("patient_id", "")
    as_of = res.get("as_of_date", "")
    candidates_count = res.get("candidate_trials_count", 0)
    root_hrr = res.get("human_review_required", False)
    report = res.get("report", [])

    print(f"\n================================================================================")
    print(f"PRE-SCREENING REPORT FOR PATIENT {pid} (As of Date: {as_of})")
    print(f"Candidate Trials (Stage 1 Hard Filter): {candidates_count}")
    print(f"Human Review Required: {root_hrr}")
    print(f"================================================================================\n")

    leverage_summary = res.get("evidence_leverage_summary", [])
    if leverage_summary:
        print("--------------------------------------------------------------------------------")
        for item in leverage_summary:
            msg = item.get("message", "")
            print(f"HIGHEST-LEVERAGE ACTION: {msg}")
        print("--------------------------------------------------------------------------------\n")

    if not report:
        print("No matching candidate trials found for this patient.")
        return

    for idx, entry in enumerate(report, 1):
        nct_id = entry.get("nct_id", "")
        title = entry.get("brief_title", "")
        status = entry.get("overall_status", "")
        tier = entry.get("selection_tier", "clean")
        is_fallback = entry.get("is_fallback", False)
        hrr = entry.get("human_review_required", False)
        summary = entry.get("summary", "")
        criterion_results = entry.get("criterion_results", {})

        print(f"--- [Match #{idx}] {nct_id} ---")
        print(f"Title:                 {title}")
        print(f"Recruiting Status:     {status}")
        print(f"Selection Tier:        {tier} (is_fallback={is_fallback})")
        print(f"Human Review Required: {hrr}")
        print(f"Reason Surfaced:       {summary}")
        print("\nCriteria Evaluation:")

        for crit_name, crit_data in criterion_results.items():
            state = crit_data.get("state", "UNKNOWN")
            explanation = crit_data.get("explanation", "")
            citations = crit_data.get("citations", [])
            cit_str = f" [Citations: {', '.join(citations)}]" if citations else ""
            print(f"  * {crit_name:<28s}: {state:<24s} - {explanation}{cit_str}")

        print("--------------------------------------------------------------------------------\n")


def run_single_patient(patient_id: str, dataset: dict[str, Any], args: argparse.Namespace) -> None:
    patients_map = {p["patient_id"]: p for p in dataset.get("patients", [])}
    if patient_id not in patients_map:
        print(f"\nError: Patient ID '{patient_id}' not found in dataset.\n", file=sys.stderr)
        print("Available patient IDs in dataset:", file=sys.stderr)
        list_patients(dataset)
        sys.exit(1)

    use_cache = not args.no_cache
    if args.no_cache:
        os.environ["PRESCREENER_NO_CACHE"] = "1"

    res = prescreen_patient(
        patient_id=patient_id,
        dataset_path=DATASET_PATH,
        dev_log=args.verbose,
        use_cache=use_cache,
    )

    print_patient_report(res)

    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            json.dump(res, f, indent=2)
        print(f"Full report JSON written to: {args.out}")


def run_all_patients(dataset: dict[str, Any], args: argparse.Namespace) -> None:
    patients = dataset.get("patients", [])
    use_cache = not args.no_cache
    if args.no_cache:
        os.environ["PRESCREENER_NO_CACHE"] = "1"

    print("================================================================================")
    print(f"RUNNING ALL {len(patients)} PATIENTS THROUGH PRE-SCREENING PIPELINE")
    print("================================================================================\n")

    print(f"{'Patient ID':<12s} | {'Candidates':<10s} | {'Report Count':<12s} | {'Has Fallback':<12s} | {'Human Review Req'}")
    print("-" * 75)

    for patient in patients:
        pid = patient["patient_id"]
        res = prescreen_patient(
            patient_id=pid,
            dataset_path=DATASET_PATH,
            dev_log=args.verbose,
            use_cache=use_cache,
        )
        cand_count = res.get("candidate_trials_count", 0)
        report = res.get("report", [])
        has_fallback = any(r.get("selection_tier") == "fallback" for r in report)
        root_hrr = res.get("human_review_required", False) or any(r.get("human_review_required", False) for r in report)

        print(f"{pid:<12s} | {cand_count:<10d} | {len(report):<12d} | {str(has_fallback):<12s} | {str(root_hrr)}")

    print("\n================================================================================")
    print("ALL PATIENT RUNS COMPLETE")
    print("================================================================================\n")


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Type 2 Diabetes Clinical Trial Pre-Screening Agent CLI"
    )
    parser.add_argument(
        "--patient",
        type=str,
        help="Run full pipeline for one patient ID (e.g. P-3098).",
    )
    parser.add_argument(
        "--list-patients",
        action="store_true",
        help="List all patient IDs from the dataset with age, active med count, and missing domains.",
    )
    parser.add_argument(
        "--all",
        action="store_true",
        help="Run all 15 patients through pipeline in sequence and print 1-line summary per patient.",
    )
    parser.add_argument(
        "--out",
        type=str,
        help="Path to write full report as JSON (used with --patient).",
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Enable per-stage LangGraph state logging.",
    )
    parser.add_argument(
        "--no-cache",
        action="store_true",
        help="Bypass extraction cache to force fresh LLM calls without overwriting existing cache.",
    )

    args = parser.parse_args()

    if not (args.patient or args.list_patients or args.all):
        parser.print_help()
        sys.exit(0)

    dataset = load_dataset()

    if args.list_patients:
        list_patients(dataset)
        return

    if args.patient:
        run_single_patient(args.patient, dataset, args)
        return

    if args.all:
        run_all_patients(dataset, args)
        return


if __name__ == "__main__":
    main()
